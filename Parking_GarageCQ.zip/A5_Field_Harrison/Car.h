#include <string>
#ifndef CAR_H
#define CAR_H
using namespace std;
class Car
{
    int arrival;
    int time;
    string type;
    string plate;
public:
    Car();
    Car(int, int, string, string);
    int getArrival();
    int getTime();
    int getDeparture();
    string getType();
    string getPlate();



};



#endif