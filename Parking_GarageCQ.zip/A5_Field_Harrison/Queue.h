#include <iostream>
#include "Car.h"
#ifndef QUEUE_H
#define QUEUE_H

using namespace std;
class Queue
{
private:
    int front; //index where the first data item is located
    int rear; //index where the last data item is located
    int size; //number of data items in the queue
    int capacity; //how many data items can be held in the array
    Car* array; //a pointer to an array in the heap
public:
    Queue();
    Queue(int);
    //must be defined when a class has a pointer as a data member
    ~Queue();
    Queue(Queue&);
    Queue& operator=(Queue&);
    //these three ^
    //functions for queue
    void enqueue(Car*);
    void dequeue();
    void print(ostream&);
    int getSize();


    

};




#endif