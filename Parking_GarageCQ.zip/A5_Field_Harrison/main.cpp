#include <iostream>
#include <fstream>
#include <cassert>
#include <sstream>
#include "Car.h"
#include "Queue.h"
using namespace std;

int main()
{
    Queue q1(21);
    fstream fin("park.txt", ios::in);
    if(fin.is_open())
    {
        string input;
        cout << endl << "============ PARKING ============" << endl;
        while(getline(fin,input))
        {
            istringstream iss(input);
            string type, plate;
            int arrival, time;
            iss >> arrival >> time >> type >> plate;
            Car* p = new Car(arrival, time, type, plate);
            q1.enqueue(p);
        }
        cout << endl;
    }
    else cout << "file not found." << endl;

    cout << "Number of cars parked: " << q1.getSize() << endl;

    cout << endl << "============ DEPARTING ============" << endl;
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    q1.dequeue();
    cout << "\nNumber of cars parked: " << q1.getSize() << endl << endl;

    return 0;
}


