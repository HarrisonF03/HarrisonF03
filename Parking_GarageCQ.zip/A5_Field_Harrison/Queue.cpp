#include <iostream>
#include <algorithm>
#include <iomanip>
#include "Queue.h"
#include "Car.h"
using namespace std;

Queue::Queue()
{
    capacity = 10;
    front = 0;
    rear = (capacity - 1);
    size = 0;
    array = new Car[capacity];
}
Queue::Queue(int cap)
{
    capacity = cap;
    front = 0;
    rear = (capacity - 1);
    size = 0;
    array = new Car[capacity];
}
Queue::~Queue()
{
    delete [] array;
}
Queue::Queue(Queue& right)
{   
    capacity = right.capacity;
    front = right.front;
    rear = right.rear;
    size = right.size;
    array = new Car[capacity];

    if(size != 0)
    {
        if(front <= rear)
        {
            for(int i = front; i <= rear; i++)
            {
                array[i] = right.array[i];
            }
        }
        else
        {
            for(int i = front; i < capacity; i++)
            {
                array[i] = right.array[i];
            }
            for(int i = 0; i <= rear; i++)
            {
                array[i] = right.array[i];
            }
        }
    }
    else cout << "Queue is empty" << endl;

}
Queue& Queue::operator=(Queue& right)
{
    Queue local = right;
    Car* temp;
    temp = array;
    array = local.array;
    local.array = temp;
    return *this;
}
void Queue::enqueue(Car *c)
{
    cout << "Park at: " << setw(4) << setfill('0') << c->getArrival() << "   " << c->getPlate() << "   " << c->getType() << endl;
    
    if(size == capacity)
    {
        cout << "Queue is full." << endl;
        return;
    }
    
    rear = ++rear % capacity;
    array[rear] = *c;
    size++;

    for(int i = 0; i < size - 1; i++)
    {
        for(int j = 0; j < size - 1; j++)
        {
            if(array[j].getDeparture() > array[j + 1].getDeparture())
            {
                Car temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
    
}
void Queue::dequeue()
{
    cout << "Depart at: " << setw(4) << setfill('0') << array[front].getDeparture() << "   " << array[front].getPlate() << "   " << array[front].getType() << endl ;
    
    if(size == 0)
    {
       cout << "Queue is empty." << endl;
       return;
    }
    
    front = ++front % capacity;
    size--;

}
int Queue::getSize()
{
    return size;
}

