#include <iostream>
#include "Car.h"
using namespace std;

Car::Car()
{
    arrival = 0;
    time = 0;
    type = "";
    plate = "";
}
Car::Car(int arrival, int time, string type, string plate)
{
    this->arrival = arrival;
    this->time = time;
    this->type = type;
    this->plate = plate;
}
int Car::getArrival()
{
    return arrival;
}
int Car::getDeparture()
{
    int departure = (arrival + time);
    return departure;
     
}
int Car::getTime()
{
    return time;
}
string Car::getType()
{
    return type;
}
string Car::getPlate()
{
    return plate;
}


