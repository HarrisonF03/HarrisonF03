#include <iostream>
#include "Node.h"
using namespace std;

Node::Node() //this
{
    cout << "\t Node() called: " << this << endl;
    this->item = nullptr;
    this->next = nullptr;
}

Node::Node(Employee * e) //this
{
    cout << "\t Node(int) called: " << this << endl;
    this->item = e;
    this->next = nullptr;
}

Node::~Node() //this
{
    cout << "\t ~Node() called: " << this << endl;
    //delete item;
    
}