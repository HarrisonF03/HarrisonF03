#ifndef NODE_H
#define NODE_H

#include "employee.h"

struct Node
{
    Employee* item;
    Node* next;

    Node();
    Node(Employee*);
    ~Node();//destructor, not for deleting the next node container

};

#endif