#ifndef EXTERN_FUNC_H
#define EXTERN_FUNC_H

extern ostream& operator<<(ostream&, Employee&);

#endif