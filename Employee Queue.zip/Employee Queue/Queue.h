#ifndef QUEUE_H //Queue_H called a macro
#define QUEUE_H
#include "Node.h"
#include "employee.h"

class Queue
{
private: 
    Node* front;
    Node* rear;
public: 
    Queue();
    ~Queue();
    Queue(Queue&); // copy constructor
    Queue& operator=(Queue&); //operator overload

    void enqueue(Employee*);
    void dequeue();
    Node* getTop() const
    {
        return front;
    }
};









#endif