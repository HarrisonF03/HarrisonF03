#ifndef EMPLOYEE_H // ifndef directive: if EMPLOYEE_H isnt defined
#define EMPLOYEE_H // then define employee_h
#include <string>

using namespace std;
class Employee
{
    // member variables to declare the attributes of employee
private:
    char code;
    string ssn;
    string firstname;
    string lastname;
    string dept;
    string role;
    double salary;
    char *info; // almost always dynamic memory reservation

public:
    Employee();

    Employee(char, string, string, string, string, string, double);

    Employee(char, string, string, string, string, string, double, char *);
    Employee(Employee &);
    ~Employee();
    Employee &operator=(Employee &);
    // getters or accessors: get the value of a member variable and return the value

    char get_code() const;
    string get_ssn() const;
    string get_lastname() const;
    string get_firstname() const;
    string get_dept() const;
    string get_role() const;
    double get_salary() const;
    // how to get the info
    string get_info() const;

    // setter or mutators or manipulators: set the value of a member variable
    void set_code(char);
    void set_ssn(string);
    void set_lastname(string);
    void set_firstname(string);
    void set_dept(string);
    void set_role(string);
    void set_salary(double);
    void set_info(string);
};

#endif // # end of the definiton
