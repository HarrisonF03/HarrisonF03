#include <iostream>
#include <iomanip>
#include "employee.h"

using namespace std;
ostream& operator<<(ostream& out, Employee& e)
{
    out << fixed << setprecision(2) << left << setw(6) << e.get_code() << setw(15) 
    << e.get_ssn() << setw(10) << e.get_lastname() << setw(15) << e.get_firstname()
    << setw(15) << e.get_dept() << setw(24) << e.get_role() << setw(13) << e.get_salary() << endl;
    
    return out;
}