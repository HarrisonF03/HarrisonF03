#include <iostream>
#include <cstring>
#include "employee.h"

Employee::Employee() //::-> scope resolution operator
                     // without it, employee() becomes free function like main()
                     // Employee:: -> makes Employee() a member function of Employee type
{
    // a member function can directly access or modify member variables of the same type
    // within the definition of a member function, dont use Employee:: nor redeclare an attribute
    cout << "Employee() called" << this << endl;
    code = 'S';
    ssn = "111-22-3333";
    firstname = "FNU";
    lastname = "LNU";
    dept = "DNU";
    role = "RNU";
    salary = 0.0;
    info = nullptr;
}

Employee::Employee(char c, string ssn, string fn, string ln, string dept, string r, double salary)
{
    // cout << "\tEmployee(char, string,,,,) called" << endl;
    code = c;
    this->ssn = ssn; // this: a pointer to an Employee object
                     // Employee s('S', '123-45-1234', 'Harrison', 'Field', 'CS', 'Faculty', 1000000)
                     // automatic call of the arg-constructor
                     // this is the address of s
                     // Employee s2('S', '123-45-1234', 'Harrison', 'Field', 'CS', 'Faculty', 1000000)
                     // this-> : pointer-> to access a member of an aggregate type
    firstname = fn;
    lastname = ln;
    this->dept = dept;
    role = r;
    this->salary = salary;
    info = nullptr;
}

Employee::Employee(char c, string ssn, string fn, string ln, string dept, string r, double salary, char *comment)
{
    // cout << "\tEmployee(char, string,,,,) called" << this << endl;
    code = c;
    this->ssn = ssn; // this: a pointer to an Employee object
                     // Employee s('S', '123-45-1234', 'Harrison', 'Field', 'CS', 'Faculty', 1000000)
                     // automatic call of the arg-constructor
                     // this is the address of s
                     // Employee s2('S', '123-45-1234', 'Harrison', 'Field', 'CS', 'Faculty', 1000000)
                     // this-> : pointer-> to access a member of an aggregate type
    firstname = fn;
    lastname = ln;
    this->dept = dept;
    role = r;
    this->salary = salary;
    // 1. find the length of the c- string, info
    char *p = comment;
    int length = 0;

    while (*p != '\0')
    {
        length++;
        p++;
    }
    // 2. dynamic array allocation with the length + 1 for '\0'
    // this -> info = info; //this -> info employees info has the same address as the info set by the constructor
    // correct implementation: copy the c- string
    this->info = new char[length + 1]; // +1 for '\0' --> each employee that has non-null info uses dynamic memory
    p = comment;                       // local (Employee's info)
    for (int i = 0; i < length; i++)
    {
        info[i] = *p;
        p++;
    }                    // copies the info from Employee into its own memory address in the heap
    info[length] = '\0'; // putting null character at the end
}
// Q1: what code in the main() calls the copy constructor?
// A1: Employee e3(e2);
// Syntax analysis:
//                 1. memory reservation for a new object e3
//                 2. initialize each memeber of e3 using the value of the same member of e2
//                 3. distinguish when operator=() is called instead of copy constructor
//                   e3 = e2; --> call operator=():
// Q2:Do you create a new object in this code?
// A2: Employee e5 = e2 --> copy constructor call although it appears to be operator overloading
// Q3: are we creating a new object using an existing object?
// A3: No we are creating a new object entirely In other words we have a data type before the variable name
Employee::Employee(Employee &right)
{
    code = right.code;
    ssn = right.ssn;
    firstname = right.firstname;
    lastname = right.lastname;
    dept = right.dept;
    role = right.role;
    salary = right.salary;

    // deep copy for info
    // 1. find the length of the c-string pointed by the info of right
    char *p = right.info;
    int len = 0;
    while (*p != '\0')
    {
        len++;
        p++; // 1byte advance
    }
    // 2. created a dynamic array
    info = new char[len + 1];
    // 3.
    p = right.info;
    for (int i = 0; i < len; i++)
    {
        info[i] = p[i];
        info[len] = '\0';
    }
}

Employee::~Employee() // a hidden variable, this,
{
 //if(info != nullptr)delete[] info;
 
}
// Q1:why return type is a reference of employee?
// A1: for a cascading assignment: e3 = e2 = e1;
//       how to interpret e3 = e2 = e1;
//       the compiler converts e3 = e2 = e1 to
//                            e3.operator=( e2.operator = (e1) );
//                                           *this ==> e2
//                            e3.operator=(e2);
//   e2.operator=(e1) ==> e2 is an object that calls operator=()
//                    ==> meaning &e2 is the hidden parameter, this to operator=()
// Q2: why Employee& for the parameter, right?
// A2: If it were Employee without &, a local variable will be created, which is a copy of the argument
//     Typically, a class has multiple attributes, you do not want to pass by value
Employee &Employee::operator=(Employee &right) // left_obj = right_obj/
{
    // cout << "\toperator = (employee&) called : " << this << endl;
    // cout << "\t&right = " << &right << endl;
    // standard implementation recommended by the industry
    // 1. create a local object using right
    // cout << "Local created" << endl;
    Employee local(right); // copy constructor call
                           // Employee: data type
                           // local; a variable name
                           //(): constructor call
                           // right: parameter whose type is Employee&
    // 2. shallow copy and deep copy by swapping the pointers, info
    // 2.1 shallow copy for non pointer member variables using the local object
    code = local.code;
    ssn = local.ssn;
    firstname = local.firstname;
    lastname = local.lastname;
    dept = local.dept;
    role = local.role;
    salary = local.salary;

    // 2.2 deep copy for pointer member variable(s) by swapping pointers
    // between local and *this
    char *temp = info; // this-> info is the same as info
    info = local.info; //
    local.info = temp; //

    // 3. return *this;
    // cout << "Local out of scope" <<endl;
    return *this; // this is the pointer of an object that operator=() recieves as a hidden paramenter
                  //*this is dereferencing this pointer --> object itself but as a reference (due to the return type being employee&)
                  // now, the object named local is out of scope
                  // meaning, the local object will call its destructor
                  //, the destructor will delete the heap pointed by info of the local
                  // since we swapped the info pointers, the locals info is pointing to the info of e2
}

char Employee::get_code() const
{
    return code;
}
string Employee::get_ssn() const
{
    return ssn;
}
string Employee::get_lastname() const
{
    return lastname;
}
string Employee::get_firstname() const
{
    return firstname;
}
string Employee::get_dept() const  
{
    return dept;
}
string Employee::get_role() const
{
    return role;
}
double Employee::get_salary() const
{
    return salary;
}
string Employee::get_info() const
{
    return (string)info;
}
// how to get the info

// setter or mutators or manipulators: set the value of a member variable
void Employee::set_code(char code)
{
    this->code = code; //the parameter code is a local variable
                       //this->code is a member of an employee
}
void Employee::set_ssn(string ssn)
{
    this->ssn = ssn;
}
void Employee::set_lastname(string lastname)
{
    this->lastname = lastname;
}
void Employee::set_firstname(string firstname)
{
    this->firstname = firstname;
}
void Employee::set_dept(string dept)
{
    this->dept = dept;
}
void Employee::set_role(string role)
{
    this->role = role;
}
void Employee::set_salary(double salary)
{
    this->salary = salary;
}
void Employee::set_info(string comment)
{
    if(info)
        {
            delete[] info;
        }
        info = new char[comment.length() + 1];
        strncpy(info, comment.c_str(), comment.length());
        info[comment.length()] = '\0';
}