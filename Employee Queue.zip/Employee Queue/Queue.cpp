#include <iostream>
#include "Node.h"
#include "Queue.h"

using namespace std;

Queue::Queue()
{
    cout << "Queue::Queue() called: " << this << endl;
    this->front = nullptr; //top = nullptr
    this->rear = nullptr;
}
Queue::~Queue() //destructor
{ 
    cout << "Queue::~Queue() called: " << this << endl;
    while(front != nullptr)
    {
        Node* temp = front;
        front = front-> next;
        delete temp;
    }
    rear = nullptr;
}
Queue::Queue(Queue& right) //copy constructor
{
    Node *right_temp = right.front;

    if(right_temp == nullptr)
    {
        front = nullptr;
        rear = nullptr;
        return;
    }

    front = new Node (right_temp->item);
    Node *this_temp = front;

    while(right_temp->next != nullptr)
    {
        this_temp->next = new Node(right_temp->next->item);
        right_temp = right_temp->next;
        this_temp = this_temp->next;
    }

    this_temp->next = nullptr;
    rear = this_temp;
    
} 
Queue &Queue::operator=(Queue& right) //operator overload
{
    if(this != &right)
    {
        Queue local(right);
        Node *temp = front;
        front = local.front;
        local.front = temp; 
        rear = local.rear;
    }
    return *this;
}

void Queue::enqueue(Employee* e)
{
    //1. create a new container for the new value
    Node* temp = new Node(e);
    if(rear != nullptr) 
    {                           //queue is not empty
        rear->next = temp;
        rear = rear->next;
    }                           //at least 2 nodes, nullptr->: segmentation fault
    else                    //queue is empty
        front = rear = temp; // single node case
}
void Queue::dequeue() //delete front node and make the next node the new front node
{
    if(front == nullptr)
    {
        cout << "Queue is empty." << endl;
    }
    
    else 
    {
        Node* temp = front;
        front = front->next;
        delete temp;
        //what if no node in the queue anymore? rear is now a dangling pointer;
        if(front == nullptr)
        {
            rear = nullptr;
        }
    }

}