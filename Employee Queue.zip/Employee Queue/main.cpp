#include <iostream>
#include <fstream>
#include <cassert>
#include <sstream>
#include "employee.h"
#include "Queue.h"
#include "extern_func.h"

using namespace std;

void printList (Node* head);

int main()
{

    fstream fin("employee.txt", ios::in);
    if(fin.fail())
    {
        cout << "File not found.\n";
        assert(false);
    }
     cout << "Creating q1..." << endl;
    Queue q1;

    string input;
    while(getline(fin, input))
    {
        istringstream iss(input); //type variable(source)
        char code;
        string ssn, firstname, lastname, dept, role, salary;
        iss >> code >> ssn >> firstname >> lastname >> dept >> role >> salary;
        Employee* p = new Employee(code, ssn, firstname, lastname, dept, role, stof(salary));
        cout << (*p);
        q1.enqueue(p);
    }

    cout << "Creating s2... " << endl;
    cout << "q2 = q1" << endl;

    Queue q2 = q1;

    cout << "q2: 1 dequeue()..." << endl;
    q2.dequeue();

    return 0;
}
void printList(Node* head)
{
    while(head != nullptr)
    {
        cout << head->item << endl;
        head = head->next;
    }
    cout << endl;
}