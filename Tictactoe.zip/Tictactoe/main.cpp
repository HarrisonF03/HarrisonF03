#include <iostream>
#include <vector>
using namespace std;

const int N = 3;
char board[N][N]; // creates the 3x3 board

bool check_win(char player) {
    for (int i = 0; i < N; i++) {
        if (board[i][0] == player && board[i][1] == player && board[i][2] == player) //checks every row
            return true;
        if (board[0][i] == player && board[1][i] == player && board[2][i] == player) // checks every column
            return true;
    }
    if (board[0][0] == player && board[1][1] == player && board[2][2] == player)// checks the diagonal
        return true;
    if (board[0][2] == player && board[1][1] == player && board[2][0] == player) // checks the other diagonal
        return true;// returns true to end game
    return false; // returns false to continue game
}

void print_board() {
    cout << "  1 2 3" << endl; // this prints the columns
    for (int i = 0; i < N; i++) { //this prints the rows
        cout << i+1 << " ";
        for (int j = 0; j < N; j++)
            cout << board[i][j] << " ";
        cout << endl;
    }
}

int main() {
    char player1 = 'O', player2 = 'X', current_player = player1; // initializes the players
    int num_moves = 0, row, col; // sets the number of moves to 0
    bool game_over = false; //false means the game continues

    for(int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            board[i][j] = ' '; // sets the 2D array to have spaces (clears the board)

    while (!game_over) {
        print_board();
        cout << "Player " << current_player << ", enter row and column numbers (1-3) of your move: ";
        cin >> row >> col; //above gives instruction and this line reads in the user input
        if (row < 1 || row > N || col < 1 || col > N) { //sets limits for the input
            cout << "Invalid move! Row and column numbers must be between 1 and 3." << endl;
            continue;
        }
        if (board[row-1][col-1] != ' ') { //determines if the space is occupied
            cout << "Invalid move! That space is already occupied." << endl;
            continue;
        }
        board[row-1][col-1] = current_player;// assigns the selected point to either X or O;
        num_moves++;
        if (check_win(current_player)) { //checks for a win every iteration
            cout << "Congratulations, Player " << current_player << " wins!" << endl;
            print_board();
            game_over = true;
        }
        else if (num_moves == N*N) { //if the board is maxed out or 9 moves are used the game ends
            cout << "Game over! It's a tie." << endl;
            print_board();
            game_over = true;
        }
        current_player = (current_player == player1) ? player2 : player1;// determines which player is next based on which player was last
    }

    return 0;
}
